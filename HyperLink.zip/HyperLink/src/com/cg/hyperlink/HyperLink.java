package com.cg.hyperlink;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HyperLink {

	static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		String baseUrl = "http://localhost:9091/HyperLink/link.html";
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(baseUrl);

		driver.findElement(By.partialLinkText("Inside")).click();
		driver.navigate().back();

		driver.findElement(By.linkText("Outer")).click();
		driver.navigate();

		Thread.sleep(1000);
		driver.quit();

	}

}
