package com.cg.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class JspController {

	@RequestMapping("/")
	public String sayHello() {
		return "home";

	}

	@RequestMapping("/profile")
	public String profilePage() {
		return "profile";
	}

	@RequestMapping("/order")
	public String orderPage() {
		return "order";
	}

	@RequestMapping("/wishlist")
	public String wishlistPage() {
		return "wishlist";
	}

	@RequestMapping("/feed")
	public String feedbacktPage() {
		return "feedback";
	}

}