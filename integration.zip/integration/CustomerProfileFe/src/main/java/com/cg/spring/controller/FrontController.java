package com.cg.spring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.bean.Customer;

@RestController
public class FrontController {
	@RequestMapping("/customer")
	public ModelAndView showCustomerProfile() {
		RestTemplate rt = new RestTemplate();
		List<Customer> p = rt.getForObject("http://localhost:8000/show", ArrayList.class);
		return new ModelAndView("customer", "cust", p);

	}

	@RequestMapping("/changeProfile")
	public Customer updateProfile(@RequestParam String Name,
			@RequestParam String Email, @RequestParam String Phone, @RequestParam String Gender,
			@RequestParam String Address) {

		RestTemplate rt = new RestTemplate();
		Customer cp = rt.getForObject("http://localhost:8000/profile?Name=" + Name + "&Email=" + Email + "&Phone="
				+ Phone + "&Gender=" + Gender + "&Address=" + Address, Customer.class);
		return cp;

	}
	@RequestMapping("/feedback")
	public ModelAndView updateFeedback(@RequestParam String product, @RequestParam String feedback) {

		RestTemplate rt = new RestTemplate();
		rt.put("http://localhost:8000/feed?product=" + product + "&feedback=" + feedback, String.class);

		return new ModelAndView("display");

	}

}