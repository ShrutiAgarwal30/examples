package com.cg.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.service.IFeedbackService;

@RestController
public class FeedbackController {

	@Autowired
	IFeedbackService service;

	@RequestMapping("/feedback")
	public String updateFeedback(@RequestParam int product, @RequestParam String feedback) {
		service.updateProduct(product, feedback);
		return service.updateFeedback(product, feedback);

	}

}
