package com.cg.spring.service;

import java.util.List;

import com.cg.spring.beans.Product;

public interface IFeedbackService {

	public void updateProduct(int id, String feedback);

	List<Product> showAll();

	public String updateFeedback(int id, String feedback);

}
