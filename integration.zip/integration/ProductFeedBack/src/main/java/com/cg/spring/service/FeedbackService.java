package com.cg.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.beans.Feedback;
import com.cg.spring.beans.Product;
import com.cg.spring.repo.IFeedbackRepo;
import com.cg.spring.repo.IProductRepo;

@Service
public class FeedbackService implements IFeedbackService {

	@Autowired
	IProductRepo prepo;
	@Autowired
	IFeedbackRepo frepo;

	@Override
	public void updateProduct(int id, String feedback) {

		Product product = new Product();

		if (id == 101) {
			product.setProductId(id);
			product.setName("Iphone x");
			product.setPrice(100000);
			product.setDescription("With Iphine X the device is the display and All new 5.8-inchscreen");
			prepo.save(product);

		} else if (id == 102) {
			product.setProductId(id);
			product.setName("Nike Running Shoes");
			product.setPrice(5000);
			product.setDescription("This down shifter running shoes comes in Navy blue and white color");
			prepo.save(product);

		} else if (id == 103) {
			product.setProductId(id);
			product.setName("Parker pen");
			product.setPrice(1500);
			product.setDescription("Premium quality. Special edition pen");
			prepo.save(product);

		} else if (id == 104) {
			product.setProductId(id);
			product.setName("Mi Note5pro");
			product.setPrice(18000);
			product.setDescription("The 5'7 inch display with rounded corners");
			prepo.save(product);

		} else if (id == 105) {
			product.setProductId(id);
			product.setName("Samsung J7");
			product.setPrice(8000);
			product.setDescription("High speed browsing and 4g enabled");
			prepo.save(product);

		} else if (id == 106) {
			product.setProductId(id);
			product.setName("Shoetopia slippers");
			product.setPrice(400);
			product.setDescription("Attractive and provide comfort to feet");
			prepo.save(product);

		} else if (id == 107) {
			product.setProductId(id);
			product.setName("Flying machine jeans");
			product.setPrice(2000);
			product.setDescription("High rise and skinny fit");
			prepo.save(product);

		} else if (id == 108) {
			product.setProductId(id);
			product.setName("UCB shirt");
			product.setPrice(1600);
			product.setDescription("100% cotton, machine wash");
			prepo.save(product);

		}

	}

	@Override
	public List<Product> showAll() {
		List<Product> custList = new ArrayList<>();
		prepo.findAll().forEach(custList::add);

		return custList;
	}

	@Override
	public String updateFeedback(int id, String feedback) {

		Feedback feed = new Feedback();
		if (id != 0) {
			feed.setId(id);
			feed.setFeedback(feedback);
			frepo.save(feed);
			return "Product added succesfully !!!";
		} else {
			return "Product not present.. Feedback cannot be added!!!!";
		}

	}

}
