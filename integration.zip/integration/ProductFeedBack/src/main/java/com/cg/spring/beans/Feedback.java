package com.cg.spring.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Feedback {

	@Column(name = "product_id")
	private int id;

	@Column(name = "Feedback", length = 100)
	private String feedback;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "feed_seq")
	@SequenceGenerator(name = "feed_seq", sequenceName = "feedsequence", initialValue = 10000)
	private int feedbackid;

	public int getFeedbackid() {
		return feedbackid;
	}

	public void setFeedbackid(int feedbackid) {
		this.feedbackid = feedbackid;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

}
