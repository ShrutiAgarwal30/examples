package com.cg.spring.beans;

public class Feedback {

	private int product;

	private String feedback;

	public int getId() {
		return product;
	}

	public void setId(int product) {
		this.product = product;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}


}
