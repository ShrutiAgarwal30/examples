package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {

	@Id
	@Column(name = "product_id", length = 20)
	private int id;

	@Column(name = "product_name", length = 20)
	private String name;

	@Column(name = "product_price")
	private double price;

	@Column(name = "product_description", length = 50)
	private String description;

	public int getProductId() {
		return id;
	}

	public void setProductId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
