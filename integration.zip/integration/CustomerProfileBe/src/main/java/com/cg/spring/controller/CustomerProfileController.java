package com.cg.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.bean.Customer;
import com.cg.spring.service.ICustomerProfileService;

@RestController
public class CustomerProfileController {

	@Autowired
	ICustomerProfileService service;

	@RequestMapping("/show")
	public List<Customer> showAll() {
		return service.showAll();
	}

	@RequestMapping(value = "/profile{Name}{Email}{Phone}{Gender}{Address}")
	void updateProfile(@RequestParam String Name, @RequestParam String Email, @RequestParam String Phone,
			@RequestParam String Gender, @RequestParam String Address) {

		service.updateProfile(Name, Email, Phone, Gender, Address);
		System.out.println("Profile Added Successfully");

	}
	@RequestMapping("/feed")
	public String updateFeedback(@RequestParam int product, @RequestParam String feedback) {
		service.updateProduct(product, feedback);
		return service.updateFeedback(product, feedback);

	}

}
