package com.cg.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Customer {

	@Column(name = "name", length = 10)
	private String name;
	@Id
	@Column(name = "email", length = 30)
	private String email;
	@Column(name = "phone", length = 10)
	private String phone;
	@Column(name = "gender", length = 10)
	private String gender;
	@Column(name = "address", length = 10)
	private String address;

	public Customer() {

	}

	public Customer(String name, String email, String phone, String gender, String address) {
		super();
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.gender = gender;
		this.address = address;

	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
