package com.cg.spring.service;

import java.util.List;

import com.cg.spring.bean.Customer;

public interface ICustomerProfileService {
	public List<Customer> showAll();

	public void updateProfile(String name, String email, String phone, String gender, String address);

	public void updateProduct(int product, String feedback);

	public String updateFeedback(int product, String feedback);

}
