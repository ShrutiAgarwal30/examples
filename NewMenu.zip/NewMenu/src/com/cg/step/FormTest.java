package com.cg.step;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pojo.FormElement;

import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FormTest {
	private WebDriver driver;
	private DriverUtil driverUtil;
	private FormElement form;

	@Test
	public void test() throws Throwable {
		i_have_data();
		i_enter_the_details();
		i_click_reset();
		i_move_to_success_page();
	}

	@Before
	public void Initialization() {
		driverUtil = new DriverUtil();
		driver = driverUtil.initializeDriver("CHROME");

		form = new FormElement();
		PageFactory.initElements(driver, form);
	}

	@Given("^I have data$")
	public void i_have_data() throws Throwable {
		driver.get("http://localhost:9091/NewMenu/index.html");
	}

	@When("^I enter the details$")
	public void i_enter_the_details() throws Throwable {
		form.setUsername("admin");
		form.setDesignation("SSE");
		form.setCountry("india");
Thread.sleep(3000);
	}

	@Then("^I click reset$")
	public void i_click_reset() throws Throwable {
		form.resetClick();
	}

	@Then("^I move to success page$")
	public void i_move_to_success_page() throws Throwable {
		form.clickNext();
	}

	@After
	public void close() throws InterruptedException {
		Thread.sleep(3000);
		driver.quit();
	}
}
