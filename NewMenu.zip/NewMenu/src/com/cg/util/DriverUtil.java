package com.cg.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class DriverUtil {
	private String chromeDriverPath = "Drivers\\chromedriver.exe";

	public DriverUtil() {
		// Default constructor and do nothing
	}

	public WebDriver initializeDriver(String browserName) {

		if ("FIREFOX".equalsIgnoreCase(browserName)) {
			return firefoxDriver();
		}

		if ("CHROME".equalsIgnoreCase(browserName)) {
			return chromeDriver();

		}
		return null;
	}

	private WebDriver chromeDriver() {

		System.setProperty("webdriver.chrome.driver", chromeDriverPath);
		return new ChromeDriver();

	}

	private WebDriver firefoxDriver() {

		return new FirefoxDriver();

	}

}
