package com.cg.pojo;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class FormElement {

	@FindBy(how = How.NAME, name = "usermail")
	private WebElement username;

	@FindBy(how = How.ID, id = "designation")
	private List<WebElement> designation;

	@FindBy(how = How.NAME, name = "country")
	private WebElement country;

	@FindBy(how = How.LINK_TEXT, linkText = "Next")
	private WebElement nextLink;

	@FindBy(how = How.NAME, name = "resetbtn")
	private WebElement resetbutton;

	public void clickNext() {
		nextLink.click();
	}

	public void resetClick() {
		resetbutton.click();
	}

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys("username");
	}

	public String getDesignation() {
		return ((WebElement) designation).getAttribute("value");
	}

	public void setDesignation(String designation) {
		if (designation.equals("SE"))
			this.designation.get(0).click();
		else if (designation.equals("SSE"))
			this.designation.get(1).click();
	}

	public String getCountry() {
		return new Select(this.country).getFirstSelectedOption().getText();
	}

	public void setCountry(String country) {
		new Select(this.country).selectByVisibleText(country);
	}

}
