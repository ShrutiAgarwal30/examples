/*package com.cg.fullstack.HtmlTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HtmlTest {
	public static void main(String[] args) throws InterruptedException {

		String baseUrl = "D:\\SELENIUM\\A.html";
		System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(baseUrl);
		driver.manage().window().maximize();
		WebElement uname = driver.findElement(By.name("usermail"));
		uname.sendKeys("admin");
		WebElement pass = driver.findElement(By.name("password"));
		pass.sendKeys("admin123");
		Thread.sleep(2000);
		WebElement sub= driver.findElement(By.name("Login"));
		sub.click();
		Thread.sleep(2000);
		
		
	}
}
*/