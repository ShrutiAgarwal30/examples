package com.cg.fullstack.HtmlTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.cg.fullstack.util.DriverUtil;

public class PizzaSeliniumTesting {
	private PizzaSeliniumTesting() {
		
	}
	public static void main(String[] args) {
		DriverUtil driverUtil=new DriverUtil();
		
		String baseUrl = "D:\\BDDWorkspace\\HtmlTest\\WebContent\\pizza.html";
		
		driverUtil.setBrowserName("CHROME");
		WebDriver drivernew = driverUtil.initializeDriver(driverUtil.getBrowserName());
		drivernew.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		drivernew.get(baseUrl);
		drivernew.manage().window().maximize();
		WebElement name = drivernew.findElement(By.name("username"));
		name.sendKeys("shruti");
		WebElement topping = drivernew.findElement(By.id("pizza"));
		topping.click();
		WebElement sauce = drivernew.findElement(By.id("sel"));
		sauce.click();
		WebElement extra = drivernew.findElement(By.name("Pizza"));
		extra.click();
		WebElement deliv = drivernew.findElement(By.name("Dins"));
		deliv.sendKeys("Please get my pizza fast!!!!");
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		WebElement sub = drivernew.findElement(By.name("Login"));
		sub.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		drivernew.close();
	}
}
