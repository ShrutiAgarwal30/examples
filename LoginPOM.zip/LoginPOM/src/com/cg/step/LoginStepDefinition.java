package com.cg.step;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pojo.LoginBeans;
import com.cg.util.DriverUtil;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {

	private WebDriver driver;
	private LoginBeans logbean;
	private DriverUtil driverUtil;

	@Test
	public void callme() throws Throwable {

		i_have_username_and_password();
		i_enter_the_credentials();
		i_move_to_success_page();
	}

	@Before
	public void Initialization() {
		driverUtil= new DriverUtil();
		driver = driverUtil.initializeDriver("CHROME");
		//System.setProperty("webdriver.chrome.driver", "Drivers\\chromedriver.exe");
		//driver = new ChromeDriver();
		logbean = new LoginBeans();
		PageFactory.initElements(driver, logbean);
	}

	@Given("^I have username and password$")
	public void i_have_username_and_password() throws Throwable {
		driver.get("http://localhost:9091/LoginPOM/Login.html");
	}

	@When("^I enter the credentials$")
	public void i_enter_the_credentials() throws Throwable {
		logbean.setUsername("admin");
		logbean.setPassword("admin");
		logbean.clickNext();
		/*
		 * Alert alert = driver.switchTo().alert(); alert.getText(); alert.accept();
		 */
	}

	@Then("^I move to success page$")
	public void i_move_to_success_page() throws Throwable {
		
	}

	@After
	public void close() {
		driver.quit();
	}
}
