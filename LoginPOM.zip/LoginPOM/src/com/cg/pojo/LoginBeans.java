package com.cg.pojo;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class LoginBeans {

	@FindBy(how = How.NAME, name = "usermail")
	private WebElement username;

	@FindBy(how = How.NAME, name = "password")
	private WebElement password;

	@FindBy(how = How.NAME, name = "Login")
	private WebElement loginbutton;

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public void clickNext() {
		loginbutton.click();
	}

}
