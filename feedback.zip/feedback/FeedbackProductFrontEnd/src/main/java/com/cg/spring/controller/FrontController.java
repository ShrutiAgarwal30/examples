package com.cg.spring.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class FrontController {
	@RequestMapping("/feedback")
	public ModelAndView Profile(@RequestParam String product, @RequestParam String feedback) {

		RestTemplate rt = new RestTemplate();
		rt.put("http://localhost:7071/feedback?product=" + product + "&feedback=" + feedback, String.class);

		/* return new ModelAndView("display", "c", f); */
		return new ModelAndView("display");

	}

}
